public class Launcher {
    public static void main(String[] args) {
        GymFlowUI.main(args);
    }
}